package com.tivn.chart
import android.util.Log
// package com.rouninlabs.another_tv_remote_example
import io.flutter.embedding.android.FlutterActivity
import android.view.KeyEvent // Son add
import com.microsoft.appcenter.AppCenter
import com.microsoft.appcenter.analytics.Analytics
import com.microsoft.appcenter.crashes.Crashes
import com.microsoft.appcenter.distribute.Distribute
class MainActivity: FlutterActivity() {
    override fun dispatchKeyEvent(event: KeyEvent?): Boolean { 
        Log.d("KeyEvent","******************************KeyEvent = ${event?.keyCode}")
        // if (event?.keyCode  == KeyEvent.KEYCODE_BUTTON_SELECT || event?.keyCode  == KeyEvent. KEYCODE_DPAD_CENTER)       
        //     return super.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        // else 
            return  super.dispatchKeyEvent(event)  
        }
    override fun onCreate(savedInstanceState: Bundle) {
    super.onCreate(savedInstanceState)
    // do some thing
    // "f908ab38-87df-4341-b722-838dbeae9108"
    AppCenter.configure(application, "f908ab38-87df-4341-b722-838dbeae9108")
    if (AppCenter.isConfigured()) {
        AppCenter.start(Analytics.class)
        AppCenter.start(Crashes.class)
    }
}
}
 
