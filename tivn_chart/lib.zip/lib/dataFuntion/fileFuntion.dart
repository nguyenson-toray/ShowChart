import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:tivn_chart/dataClass/inspectionDetail.dart';

// @JsonSerializable()
class FileFuntion {
  String fileName = '';
  FileFuntion({
    required this.fileName,
  });
  String get getFileName => this.fileName;

  set setFileName(String fileName) => this.fileName = fileName;

  Future<String> get _localDir async {
    final directory = await getApplicationDocumentsDirectory();

    return directory.path;
  }

  Future<String> getPath() async {
    final path = await _localDir;
    return '$path/${fileName}';
  }

  Future<File> get _localFile async {
    final path = await _localDir;
    return File('$path/${fileName}');
  }

  Future<String> readFileToString() async {
    try {
      final file = await _localFile;
      final contents = await file.readAsString();
      return contents;
    } catch (e) {
      return 'Error-readFileToString';
    }
  }

  Future<File> writeStringToFile(String content) async {
    final file = await _localFile;
    return file.writeAsString(content);
  }

  // Fetch content from the json file
  Future<dynamic> readInspectionDetailFromFileJson() async {
    final File file = await _localFile;
    print('read file   : ' + file.path);
    List<InspectionDetail> listInspectionDetail = [];
    try {
      final String jsonString = await file.readAsString();

      print('jsonString---> :' + jsonString.toString());

      List<dynamic> data = jsonDecode(jsonString);
      listInspectionDetail =
          data.map((data) => InspectionDetail.fromJson(data)).toList();
    } catch (e) {
      print(e.toString());
    }

    return listInspectionDetail;
  }

  Future<dynamic> writeListObjectToFileJson(
      List<InspectionDetail> dataInput) async {
    final json = jsonEncode(dataInput);
    await writeStringToFile(json);
  }

  Future<dynamic> writeListInspectionToFileJson(
      List<InspectionDetail> inspectionDetails) async {
    print('writeListInspectionToFile');
    String json = jsonEncode(inspectionDetails);
    print(json);
    File file = await writeStringToFile(json);

    if (file.existsSync()) {
      print('writeListInspectionToFile OK :' + file.path);
    } else
      print('save file ERROR');
  }
}
