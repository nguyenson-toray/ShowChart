import 'package:tivn_chart/global.dart';

import '../chart/inspectionChartData.dart';
import '../dataClass/t011stInspectionData.dart';

class ChartFuntion {
  int rangeDays = 16;
  late DateTime beginDate;
  late DateTime endDate;
  int sumX06 = 0; // SL kiem l1
  int sumX07 = 0; //Sl dat lan 1
  int sumX08 = 0; //SL kiem l2
  int sumX09 = 0; //SL daty l2

  List<InspectionChartData> createChartInspectionData(
      List<T011stInspectionData> data, int line) {
    List<InspectionChartData> result = [];

    beginDate = global.today.subtract(Duration(days: rangeDays));
    data.forEach((element) {
      DateTime day = DateTime.parse(element.getX02.toString());
      try {
        if (element.getX01 == line && day.isAfter(beginDate)) {
          InspectionChartData dataOneDay = new InspectionChartData();
          dataOneDay.setDate = day;
          // sumX06 = 0; // SL kiem l1
          // sumX07 = 0; //Sl dat lan 1
          // sumX08 = 0; //SL kiem l2
          // sumX09 = 0; //SL daty l2

          sumX06 = element.getX06;
          sumX07 = element.getX07;
          sumX08 = element.getX08;
          sumX09 = element.getX09;

          dataOneDay.setQty1stOK = sumX07; // dat lan 1
          dataOneDay.setQty1stNOK = sumX06 - sumX07; //Sl loi
          dataOneDay.setQtyAfterRepaire = sumX08;
          dataOneDay.setRationDefect1st =
              (sumX06 - sumX07) / sumX06; // ti le loi l1
          dataOneDay.setRationDefectAfterRepaire = ((sumX08 - sumX09) / sumX08);
          print(' dataOneDay.setQty1stOK - sumX07 sumX07 sumX07 = ' +
              sumX07.toString());
          result.add(dataOneDay);
        }
      } catch (e) {
        print(e.toString());
      }
    });

    return result;
  }
}
