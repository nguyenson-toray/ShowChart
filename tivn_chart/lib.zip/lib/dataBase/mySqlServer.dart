import 'package:connect_to_sql_server_directly/connect_to_sql_server_directly.dart';
import 'package:tivn_chart/dataClass/T07Size.dart';
import 'package:tivn_chart/dataClass/t011stInspectionData.dart';
import 'package:tivn_chart/dataClass/t03ProductionItem.dart';
import 'package:tivn_chart/dataClass/t04PlanProduction.dart';
import 'package:tivn_chart/dataClass/t06Color.dart';
import 'package:tivn_chart/global.dart';

class MySqlServer {
  bool isLoading = false;
  var connection = ConnectToSqlServerDirectly();
  final String ip = '192.168.1.11';
  final String db = 'test';
  final user = 'production';
  final pass = 'Toray@123';
  final String instanceSql = 'MSSQLSERVER';
  final String tableT00Trans = '[T00_Trans]';
  final String tableT02Trans = '[T02_Week]';
  final String tableT011stInspectionData = '[T01_1st inspection data]';
  final String table03ProductionItem = '[T03_Product item]';
  final String table04PlanProduction = '[T04_Plan production]';
  final String table05ManPowerSewingTime = '[T05_Man_power_sewing_time]';
  final String table06Color = '[T06_Color]';
  final String table07Size = '[T07_Size]';
  Future<bool> checkConnection() async {
    var isConnected = false;
    try {
      isConnected = await connection.initializeConnection(
        ip,
        global.dbNameSQL,
        user,
        pass,
        instance: instanceSql,
      );
    } catch (e) {
      print(e.toString());
    }
    return isConnected;
  }

  Future<void> getAllDataFromServer() async {
    print('==========getAllDataFromServer=============');
    try {
      global.t01s = await global.mySqlServer.selectAllTable01InspectionData();
      // global.t03s = await global.mySqlServer.selectAllTable03ProductionItem();
      // global.t04s = await global.mySqlServer.selectAllTable04PlanProduction();
      // global.t06s = await global.mySqlServer.selectAllTable06Color();
      // global.t07s = await global.mySqlServer.selectAllTable07Size();
    } catch (e) {
      print(e.toString());
    }
  }

  Future<void> getDataFromServer() async {
    print('==========getDataFromServer=============');
    try {
      String date;
      global.t01s = await global.mySqlServer.selectAllTable01InspectionData();
      global.t03s = await global.mySqlServer.selectAllTable03ProductionItem();
      global.t04s = await global.mySqlServer.selectAllTable04PlanProduction();

      global.t04s.forEach((element) {
        date = element.getX021;
        if (date == global.todayString &&
            element.getX011 == global.currentLine) {
          global.inspectionSummaryDay.setplanToday =
              element.getX13; //so luong KH
          print('global.inspectionSummaryDay.setplanToday = ' +
              global.inspectionSummaryDay.getplanToday.toString());
          return;
        }
      });
      global.t06s = await global.mySqlServer.selectAllTable06Color();
      global.t07s = await global.mySqlServer.selectAllTable07Size();
    } catch (e) {
      print(e.toString());
    }
  }

  Future<bool> updateInspectionDataToT01(
    T011stInspectionData input,
  ) async {
    String query = '';
    bool result = false;
    var date = input.getX02;
    // var date = DateFormat(global.dateFormat).format(
    //   input.getX02,
    // );
    if (input.getX06 == 1) {
      query =
          '''INSERT INTO ${tableT011stInspectionData} (X01, X02, X03, X04, X05, X06, X07, X08, X09, X10 ) 
        VALUES( ${input.getX01}, '${date}', ${input.getX03}, '${input.getX04}', '${input.getX05}', ${input.getX06}, ${input.getX07}, ${input.getX08}, ${input.getX09}, ${input.getX10})''';
    } else {
      query = '''UPDATE $tableT011stInspectionData
        SET X06 = ${input.getX06}
        WHERE  (X02='${date}' and  X01=${input.getX01} and X03= ${input.getX03} and X04= '${input.getX04}' and X05= '${input.getX05}' )
        ;''';
    }
    print('updateInspectionDataToT01 : ' + query);
    var isConnected = false;
    try {
      isConnected = await connection.initializeConnection(
        ip,
        global.dbNameSQL,
        user,
        pass,
        instance: instanceSql,
      );
      if (isConnected) {
        connection.getStatusOfQueryResult(query).then((value) => {
              if (value.runtimeType == String)
                {print('insert NNNNNNNNNOKKKKKKKKKKKKKKK')}
              else
                {
                  result = value,
                  if (value) {print('insert OKKKKKKKKKKKKKKK')}
                }
            });
      }
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<List<T011stInspectionData>> selectAllTable01InspectionData() async {
    List<T011stInspectionData> result = [];
    List<Map<String, dynamic>> tempResult = [];
    int rangeDays = 16;
    late DateTime beginDate;
    beginDate = global.today.subtract(Duration(days: rangeDays));
    late DateTime day;
    final String query = '''select * from $tableT011stInspectionData''';
    print('selectAllTable01InspectionData : ' + query);
    var isConnected = false;
    try {
      isConnected = await connection.initializeConnection(
        ip,
        global.dbNameSQL,
        user,
        pass,
        instance: instanceSql,
      );
      if (isConnected) {
        var rowData;
        var date;
        await connection.getRowsOfQueryResult(query).then((value) => {
              if (value.runtimeType == String)
                {print('Query : $query => ERROR ')}
              else
                {
                  tempResult = value.cast<Map<String, dynamic>>(),
                  for (var element in tempResult)
                    {
                      rowData = T011stInspectionData.fromMap(element),
                      day = DateTime.parse(rowData.getX02.toString()),
                      if (day.isAfter(beginDate))
                        {
                          result.add(rowData),
                        }
                    }
                }
            });
      }
    } catch (e) {
      e.toString();
    }
    print('List<T011stInspectionData>=leght = ' + result.length.toString());
    return result;
  }

  Future<List<T03ProductionItem>> selectAllTable03ProductionItem() async {
    List<T03ProductionItem> result = [];
    final String query = 'select * from $table03ProductionItem';
    print('selectAllTable03ProductionItem : ' + query);
    // print('selectAllTable03ProductionItem : $query');
    List<Map<String, dynamic>> tempResult = [];
    var isConnected = false;
    try {
      isConnected = await connection.initializeConnection(
        ip,
        global.dbNameSQL,
        user,
        pass,
        instance: instanceSql,
      );
      if (isConnected) {
        await connection.getRowsOfQueryResult(query).then((value) => {
              if (value.runtimeType == String)
                {print('Query : $query => ERROR ')}
              else
                {
                  tempResult = value.cast<Map<String, dynamic>>(),
                  for (var element in tempResult)
                    {
                      result.add(T03ProductionItem.fromMap(element)),
                    }
                }
            });
      }
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<List<T04PlanProduction>> selectAllTable04PlanProduction() async {
    List<T04PlanProduction> result = [];
    List<Map<String, dynamic>> tempResult = [];
    final String query = '''select * from $table04PlanProduction''';
    print('selectAllTable04PlanProduction : $query');
    var isConnected = false;
    try {
      isConnected = await connection.initializeConnection(
        ip,
        global.dbNameSQL,
        user,
        pass,
        instance: instanceSql,
      );
      if (isConnected) {
        await connection.getRowsOfQueryResult(query).then((value) => {
              if (value.runtimeType == String)
                {print('Query : $query => ERROR ')}
              else
                {
                  tempResult = value.cast<Map<String, dynamic>>(),
                  for (var element in tempResult)
                    {result.add(T04PlanProduction.fromMap(element))}
                }
            });
      }
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<List<T06Color>> selectAllTable06Color() async {
    List<T06Color> result = [];
    List<Map<String, dynamic>> tempResult = [];
    final String query = '''select * from $table06Color''';
    print('selectAllTable06Color : $query');
    var isConnected = false;
    try {
      isConnected = await connection.initializeConnection(
        ip,
        global.dbNameSQL,
        user,
        pass,
        instance: instanceSql,
      );
      if (isConnected) {
        await connection.getRowsOfQueryResult(query).then((value) => {
              if (value.runtimeType == String)
                {print('Query : $query => ERROR ')}
              else
                {
                  tempResult = value.cast<Map<String, dynamic>>(),
                  for (var element in tempResult)
                    {result.add(T06Color.fromMap(element))}
                }
            });
      }
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<List<T07Size>> selectAllTable07Size() async {
    List<T07Size> result = [];
    List<Map<String, dynamic>> tempResult = [];
    final String query = '''select * from $table07Size''';
    print('selectAllTable07Size : $query');
    var isConnected = false;
    try {
      isConnected = await connection.initializeConnection(
        ip,
        global.dbNameSQL,
        user,
        pass,
        instance: instanceSql,
      );
      if (isConnected) {
        await connection.getRowsOfQueryResult(query).then((value) => {
              if (value.runtimeType == String)
                {print('Query : $query => ERROR ')}
              else
                {
                  tempResult = value.cast<Map<String, dynamic>>(),
                  for (var element in tempResult)
                    {result.add(T07Size.fromMap(element))}
                }
            });
      }
    } catch (e) {
      print(e.toString());
    }
    return result;
  }
}
