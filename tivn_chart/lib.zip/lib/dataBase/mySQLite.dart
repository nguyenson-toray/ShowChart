import 'dart:async';
import 'package:tivn_chart/dataClass/InspectionSummaryDay.dart';
import 'package:tivn_chart/dataClass/t02Week.dart';
import 'package:sqflite/sqflite.dart';
import 'package:intl/intl.dart';
import 'package:tivn_chart/dataClass/inspectionDetail.dart';

class MySqLite {
  final String tableT00Trans = 'T00_Trans';
  final String tableT02Week = 'T02_Week';
  final String tableT011stInspectionData = 'T01_1st_inspection_data';
  final String table03ProductionItem = 'T03_Product_item';
  final String table04PlanProduction = 'T04_Plan_production';
  final String table05ManPowerSewingTime = 'T05_Man_power_sewing_time';
  final String table06Color = 'T06_Color';
  final String tableInspectionDetails = 'InspectionDetails';
  final String tableInspectionSummary = 'InspectionSummary';

  final String tableCfg = 'cfg';
  String dbPath = '';
  String dbName = 'toray.db';
  late Database database;
  String query = '';
  Future<String> getPath() async {
    String path;
    path = await getDatabasesPath();
    return '$path/$dbName';
  }

  void closeDB() {
    database.close();
  }

  Future<bool> isDbExits() async =>
      databaseFactory.databaseExists(await getPath());
  Future<void> openDB() async {
    var path = await getPath();
    database = await openDatabase(path);
  }

  Future<void> createDB() async {
    try {
      var path = await getPath();
      print('============= createDB : $path');
      database = await openDatabase(
        path,
        onCreate: (db, int version) async {
          await db.execute('$queryCreate_T03_Product_item;');
          await db.execute('$queryCreate_T04_Plan_production;');
          await db.execute('$queryCreate_InspectionDetails;');
          await db.execute('$queryCreate_InspectionSummary;');
        },
        version: 1,
      );
      // await database.close();
    } catch (e) {
      print(e.toString());
    }
  }

  Future<void> insertIntoTable(String tabelName, dynamic rowData) async {
    print('database.path = ' + database.path);
    var open = await isDbExits();
    print('is open = ' + open.toString());
    try {
      int result = await database.insert(
        tabelName,
        rowData.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      print('insertIntoTable : $tabelName -result : ' + result.toString());
    } catch (e) {
      print('insertIntoTable : $tabelName ERROR : ' + e.toString());
    }
  }

// A method that retrieves all the dogs from the dogs table.
  Future<List<InspectionDetail>> loadInspectionDetails() async {
    List<InspectionDetail> result = [];
    List<Map<String, dynamic>> maps;
    try {
      maps = await database.query(tableInspectionDetails);
      return List.generate(maps.length, (i) {
        return InspectionDetail.fromMap(maps[i]);
      });
    } catch (e) {
      print('loadInspectionDetails : ' + e.toString());
    }
    return result;
  }

  Future<List<InspectionSummaryDay>> loadInspectionSummaryDay() async {
    print('Future<List<InspectionSummaryDay>> loadInspectionSummaryDay() ');
    List<InspectionSummaryDay> result = [];
    List<Map<String, dynamic>> maps;
    try {
      maps = await database.query(tableInspectionSummary);
      return List.generate(maps.length, (i) {
        print('maps[i] : ' + maps[i].toString());
        return InspectionSummaryDay.fromMap(maps[i]);
      });
    } catch (e) {
      print('loadInspectionSummaryDay : ' + e.toString());
    }
    return result;
  }

  Future<void> updateInspectionSummary(InspectionSummaryDay dataInput) async {
    print('SQLite updateInspectionSummary');

    int id = -1;
    try {
      List<InspectionSummaryDay> dataInDB = await loadInspectionSummaryDay();
      print('---------leght = ' + dataInDB.length.toString());
      dataInDB.forEach((element) {
        if (element.getDate == dataInput.getDate &&
            element.getLine == dataInput.getLine &&
            element.getStyleCode == dataInput.getStyleCode &&
            element.getSize == dataInput.getSize) {
          //exits data => get id to update
          id = element.getId;
        } else {}
      });
      if (id != -1) {
        print('UPDATE at id = ' + id.toString());
        await database.update(
          tableInspectionSummary,
          dataInput.toMap(),
          where: 'id = ?',
          whereArgs: [id],
        );
      } else {
        print('INSERT');
        dataInput.setId =
            int.parse(DateFormat('yyyyMMddHHmmss').format(DateTime.now()));
        await insertIntoTable(tableInspectionSummary, dataInput);
      }
    } catch (e) {
      print(e.toString());
    }
  }
  // insertIntoT02Week() async {
  //   var data = T02Week();
  //   data.setWeek = 999;
  //   await database.insert(
  //     tableT02Week,
  //     data.toMap(),
  //     conflictAlgorithm: ConflictAlgorithm.replace,
  //   );
  //   var b = await database.rawQuery('SELECT * FROM $tableT02Week');
  //   print('b' + b.toString());
  // }

  final String queryCreate_T00_Month =
      r'''CREATE TABLE 'T00_Month' (ID INTEGER AUTO INCREMENT PRIMARY KEY ,  Month INTEGER   );''';
  final String queryCreate_T01_1st_inspection_data =
      r'''CREATE TABLE 'T01_1st_inspection_data' 
  (ID INTEGER AUTO INCREMENT PRIMARY KEY , 
   X01 INTEGER, X02 DATETIME default current_timestamp, X03 INTEGER, X04 VARCHAR(20),  X05 VARCHAR(20), X06 INTEGER,  X07 INTEGER,	X08 INTEGER,	X09 INTEGER,	X10 INTEGER,	
   A1 INTEGER, 	A2 INTEGER,	A3	INTEGER,
   B1	INTEGER, B2 INTEGER,	B3	INTEGER,C1	INTEGER,C2	INTEGER,D1	INTEGER,D2	INTEGER,D3 INTEGER,
   D4 INTEGER,	E1 INTEGER,	E2 INTEGER,	E3 INTEGER,	E4 INTEGER,	E5 INTEGER,	E6 INTEGER,	E7 INTEGER,	
   F1 INTEGER,	F2 INTEGER,	F3 INTEGER,	F4 INTEGER,	F5 INTEGER,	F6 INTEGER,	F7 INTEGER,	F8 INTEGER,	F9 INTEGER,	
   G1 INTEGER,	G2 INTEGER,	G3 INTEGER,	H INTEGER,
   XC TEXT,	'Sum A' INTEGER, 	'Sum B' INTEGER,	'Sum C' INTEGER,	'Sum D' INTEGER,	'Sum E' INTEGER,	'Sum F' INTEGER,	'Sum G' INTEGER, 	
   Total INTEGER,	X11 INTEGER,	X12 INTEGER,	'T-Month' INTEGER,	'T-Year' INTEGER,	TF INTEGER
  );''';
  final String queryCreate_T02_Week = r'''c''';
  final String queryCreate_T03_Product_item =
      r'''CREATE TABLE 'T03_Product_item111' (ID INTEGER AUTO INCREMENT PRIMARY KEY ,ID1 INTEGER, X151 VARCHAR(20), 
      X131 VARCHAR(20),X18 VARCHAR(20), X19 VARCHAR(50), X20 INTEGER);''';
  final String queryCreate_T04_Plan_production =
      r''' CREATE TABLE 'T04_Plan_production' (ID INTEGER AUTO INCREMENT PRIMARY KEY,	X021DATETIME default current_timestamp,	X011 INTEGER,	X13	INTEGER, 'T-Year' INTEGER, 'T-Month' INTEGER);''';
  final String queryCreate_T05_Man_power_sewing_time =
      r'''CREATE TABLE 'T05_Man_power_sewing_time' (
  ID INTEGER AUTO INCREMENT PRIMARY KEY, X01 INTERGER, X024 DATETIME default current_timestamp,	
  Mplan INTERGER,	Mact INTERGER,	Madd INTERGER,	OVT INTERGER,	X21 INTERGER, 
  'A-Month' INTERGER,	'A-Year' INTERGER);''';
  final String queryCreate_T06_Color = r'''
''';
  final String queryCreate_T07_Size = r'''
''';
  final String queryCreate_InspectionDetails = r'''
 CREATE TABLE 'InspectionDetails' (id INTEGER AUTO INCREMENT PRIMARY KEY ,time INTEGER, date  DATETIME, line INTERGER, customer VARCHAR(20), style VARCHAR(20),
  styleCode INTERGER, color VARCHAR(20), size VARCHAR(20),  spectionFirstSecond INTEGER, 
  quantity INTERGER, result VARCHAR(20), groupDefect VARCHAR(20), defect VARCHAR(20)
  );
''';
  final String queryCreate_InspectionSummary = r'''
CREATE TABLE 'InspectionSummary' (id INTEGER AUTO INCREMENT PRIMARY KEY ,date  DATETIME, time INTEGER,  line INTERGER, customer VARCHAR(20), style VARCHAR(20),
  styleCode INTERGER, color VARCHAR(20), size VARCHAR(20),  planToday  INTEGER, actual INTEGER, sumDefect REAL, rationDefect REAL
 );
''';
}
