import 'dart:io';

import 'package:connect_to_sql_server_directly/connect_to_sql_server_directly.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:tivn_chart/chart/inspectionChartData.dart';
import 'package:tivn_chart/dataClass/Customers.dart';
import 'package:tivn_chart/dataClass/InspectionSummaryDay.dart';
import 'package:tivn_chart/dataClass/T07Size.dart';
import 'package:tivn_chart/dataClass/t011stInspectionData.dart';
import 'package:tivn_chart/dataClass/t00Month.dart';
import 'package:tivn_chart/dataClass/t00Trans.dart';
import 'package:tivn_chart/dataClass/t02Week.dart';
import 'package:tivn_chart/dataClass/t03ProductionItem.dart';
import 'package:tivn_chart/dataClass/t04PlanProduction.dart';
import 'package:tivn_chart/dataClass/t05MainPowerSewingTime.dart';
import 'package:tivn_chart/dataClass/t06Color.dart';
import 'package:path/path.dart';
import 'package:tivn_chart/dataClass/workingPlan.dart';
import 'package:tivn_chart/dataBase/mySqlServer.dart';
import 'package:tivn_chart/dataBase/mySQLite.dart';
import 'package:tivn_chart/dataFuntion/chartFuntion.dart';
import 'package:tivn_chart/ui/InspectionPage.dart';
import 'package:tivn_chart/ui/chart.dart';
import 'dataClass/inspectionDetail.dart';

class global {
  static late SharedPreferences sharedPreferences;
  static int currentLine = 1;
  static late List<InspectionChartData> inspectionChartData;
  static ChartFuntion chartFuntion = ChartFuntion();
  static int pageIndex = 0;
  static String dbNameSQL = 'test';
  static String dbNameSQLite = 'toray.db';
  static late String dbPath;
  static var mySqlServer = MySqlServer();
  static var mySqlife = MySqLite();
  static bool isFisrtRun = false;
  static var t00Month = T00Month();
  static T011stInspectionData t01 = T011stInspectionData();
  static List<T011stInspectionData> t01s = [];
  static var t02s = T02Week();
  static var t03 = T03ProductionItem();
  static var t03s = <T03ProductionItem>[];
  static var t04 = T04PlanProduction();
  static var t04s = <T04PlanProduction>[];
  static var listT05 = T05MainPowerSewingTime();
  static var t06 = T06Color();
  static var t06s = <T06Color>[];
  static var t07 = T07Size();
  static var t07s = <T07Size>[];

  static var workingSummary = WorkingSummary();
  static var inspectionDetails = <InspectionDetail>[];
  static var inspectionDetail = InspectionDetail();
  static var inspectionSummaryDay = InspectionSummaryDay();
  static List<InspectionSummaryDay> inspectionSummaryDays = [];
  static var dataFileJson;

  static int secondsAutoGetData = 15;
  static var planToday = 9999;
  static var actualToday = 0;
  static var sumDefect = 0;

  static double ratioDefect = 0;
  static DateTime today = DateTime.now();
  static late String todayString;
  static final String dateFormat = 'yyyy-MM-dd';
  static int inspection12 = 1;
  static int selectedIndex = 0;
  static late Directory documentsDirectory;
}
