import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:syncfusion_flutter_charts/sparkcharts.dart';
import 'package:tivn_chart/chart/inspectionChartData.dart';
import 'package:tivn_chart/dataClass/t011stInspectionData.dart';
import 'package:tivn_chart/global.dart';
import 'package:intl/intl.dart';

class Chart extends StatefulWidget {
  const Chart({super.key});

  @override
  State<Chart> createState() => _ChartState();
}

class _ChartState extends State<Chart> {
  ChartSeriesController? _chartSeriesController;

  @override
  void initState() {
    // TODO: implement initState
    global.inspectionChartData = global.chartFuntion
        .createChartInspectionData(global.t01s, global.currentLine);

    Timer.periodic(new Duration(seconds: global.secondsAutoGetData), (timer) {
      intervalGetData();
    });
    super.initState();
  }

  intervalGetData() async {
    final listDataT01 =
        await global.mySqlServer.selectAllTable01InspectionData();
    if (listDataT01.length != 0) {
      setState(() {
        global.inspectionChartData.clear();
        global.inspectionChartData = global.chartFuntion
            .createChartInspectionData(listDataT01, global.currentLine);
        _chartSeriesController?.updateDataSource(
            updatedDataIndex: global.inspectionChartData.length - 1);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isSetting = false;

    return SafeArea(
      child: Scaffold(
          floatingActionButton: FloatingActionButton(
            backgroundColor: Colors.orange[300],
            onPressed: () {
              setState(() {
                isSetting = !isSetting;
              });
            },
            tooltip: 'Setting',
            child: isSetting
                ? Icon(
                    Icons.save,
                    // color: (Colors.amberAccent),
                  )
                : Icon(
                    Icons.settings,
                    // color: (Colors.amberAccent),
                  ),
          ),
          body: Padding(
            padding: const EdgeInsets.all(15.0),
            child: SfCartesianChart(
                title: ChartTitle(
                    text: "Sản lượng sản xuất & tỉ lệ lỗi - LINE " +
                        global.currentLine.toString(),
                    textStyle: TextStyle(fontSize: 40)),
                legend: Legend(
                  position: LegendPosition.bottom,
                  isVisible: true,
                ), //ten mau
                // Enable tooltip
                // tooltipBehavior: TooltipBehavior(enable: true),
                borderWidth: 2,
                primaryXAxis: CategoryAxis(labelRotation: 0),
                primaryYAxis: NumericAxis(
                  minimum: 0, //maximum: 250,
                  // interval: 10
                ),
                series: <ChartSeries<InspectionChartData, String>>[
                  StackedColumnSeries<InspectionChartData, String>(
                      onRendererCreated: (ChartSeriesController controller) {
                        _chartSeriesController = controller;
                      },
                      color: Colors.blue,
                      name: 'SL kiểm lần 1 đạt',
                      dataSource: global.inspectionChartData,
                      xValueMapper: (InspectionChartData data, _) =>
                          DateFormat('dd-MM').format(
                            data.getDate,
                          ),
                      yValueMapper: (InspectionChartData data, _) =>
                          data.getQty1stOK,
                      dataLabelSettings: DataLabelSettings(
                          isVisible: true,
                          // Positioning the data label
                          labelAlignment: ChartDataLabelAlignment.top)),

                  StackedColumnSeries<InspectionChartData, String>(
                      onRendererCreated: (ChartSeriesController controller) {
                        _chartSeriesController = controller;
                      },
                      color: Colors.orange[300],
                      dataSource: global.inspectionChartData,
                      name: 'SL kiểm lần 1 lỗi',
                      xValueMapper: (InspectionChartData data, _) =>
                          DateFormat('dd-MM').format(
                            data.getDate,
                          ),
                      yValueMapper: (InspectionChartData data, _) =>
                          data.getQty1stNOK,
                      dataLabelSettings: DataLabelSettings(
                          isVisible: true,
                          // Positioning the data label
                          labelAlignment: ChartDataLabelAlignment.top)),
                  StackedColumnSeries<InspectionChartData, String>(
                      onRendererCreated: (ChartSeriesController controller) {
                        _chartSeriesController = controller;
                      },
                      color: Colors.red,
                      dataSource: global.inspectionChartData,
                      name: 'SL kiểm sau khi sửa hàng ',
                      xValueMapper: (InspectionChartData data, _) =>
                          DateFormat('dd-MM').format(
                            data.getDate,
                          ),
                      yValueMapper: (InspectionChartData data, _) =>
                          data.getQtyAfterRepaire,
                      dataLabelSettings: DataLabelSettings(
                          isVisible: true,
                          // Positioning the data label
                          labelAlignment: ChartDataLabelAlignment.top)),
                  // StackedColumnSeries<InspectionChartData, String>(
                  //     dataSource: global.inspectionChartData,
                  //     xValueMapper: (InspectionChartData data, _) =>
                  //         DateFormat('dd-MM').format(
                  //           data.getDate,
                  //         ),
                  //     yValueMapper: (InspectionChartData data, _) =>
                  //         data.getRationDefect1st.toStringAsFixed(2)),
                  // StackedColumnSeries<InspectionChartData, String>(
                  //     dataSource: global.inspectionChartData,
                  //     xValueMapper: (InspectionChartData data, _) =>
                  //         DateFormat('dd-MM').format(
                  //           data.getDate,
                  //         ),
                  //     yValueMapper: (InspectionChartData data, _) =>
                  //         data.getRationDefectAfterRepaire.toStringAsFixed(2))
                ]),
          )),
    );
  }
}
