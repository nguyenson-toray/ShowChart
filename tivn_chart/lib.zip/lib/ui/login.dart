// import 'package:connect_to_sql_server_directly/connect_to_sql_server_directly.dart';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:tivn_chart/dataBase/MySQLite.dart';
import 'package:tivn_chart/dataClass/InspectionSummaryDay.dart';
import 'package:tivn_chart/global.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'package:tivn_chart/dataFuntion/fileFuntion.dart';
import 'package:tivn_chart/dataBase/mySqlServer.dart';
import 'package:tivn_chart/ui/chart.dart';
import 'package:tivn_chart/ui/homePage.dart';
import 'package:tivn_chart/dataBase/mySQLite.dart';
import 'dart:convert';

import '../dataFuntion/myFuntions.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  var isLoading = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        alignment: Alignment.center,
        // decoration: new BoxDecoration(
        //     gradient: new LinearGradient(
        //   begin: Alignment.topCenter,
        //   end: Alignment.bottomCenter,
        //   colors: [
        //     Color.fromARGB(255, 127, 215, 250),
        //     Color.fromARGB(255, 81, 117, 247)
        //   ],
        // )),
        child: SizedBox(
          width: 300,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 80, child: Image.asset('asset/logo.png')),
              SizedBox(
                height: 20,
              ),
              TextField(
                obscureText: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'User Name',
                  hintText: 'Enter User Name',
                ),
              ),
              SizedBox(
                height: 20,
              ),
              TextField(
                obscureText: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Password',
                  hintText: 'Enter Password',
                ),
              ),
              SizedBox(
                height: 20,
              ),
              /*
              kDebugMode ? Text("Select DB- Only in Debug mode") : Container(),
              kDebugMode
                  ? DropdownButton<String>(
                      value: global.dbNameSQL,
                      items: ['test', 'Production']
                          .toList()
                          .map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(
                            value,
                            style: TextStyle(fontSize: 11),
                          ),
                        );
                      }).toList(),
                      // Step 5.
                      onChanged: (String? newValue) {
                        setState(() {
                          global.dbNameSQL = newValue.toString();
                        });
                      },
                    )
                  : SizedBox(
                      height: 20,
                    ),
                    */
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: Colors.blueAccent, // background
                  onPrimary: Colors.white, // foreground
                ),
                onPressed: () async {
                  MyFuntions.loginInitData().then((value) => {
                        if (value)
                          {
                            // isLoading = false;
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const Chart()),
                            )
                          }
                      });
                  setState(() {
                    isLoading = true;
                  });
                },
                child: Text('Login'),
              ),
              SizedBox(
                height: 20,
              ),
              Container(
                height: 35,
                child: isLoading ? CircularProgressIndicator() : Container(),
              )
            ],
          ),
        ),
      ),
    );
  }
}
