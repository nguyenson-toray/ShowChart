import 'dart:convert';

class WorkingSummary {
  int? line = 1;
  String? Customer;
  String? style;
  int? styleCode;
  String? size;
  String? color;
  int? plan;
  int? actual;
  int? sumDefect;
  get getLine => this.line;

  set setLine(line) => this.line = line;

  get getCustomer => this.Customer;

  set setCustomer(Customer) => this.Customer = Customer;

  get getStyle => this.style;

  set setStyle(style) => this.style = style;

  get getStyleCode => this.styleCode;

  set setStyleCode(styleCode) => this.styleCode = styleCode;

  get getSize => this.size;

  set setSize(size) => this.size = size;

  get getColor => this.color;

  set setColor(color) => this.color = color;

  get getPlan => this.plan;

  set setPlan(plan) => this.plan = plan;

  get getActual => this.actual;

  set setActual(actual) => this.actual = actual;

  get getSumDefect => this.sumDefect;

  set setSumDefect(sumDefect) => this.sumDefect = sumDefect;
  WorkingSummary({
    this.line = 1,
    this.Customer = 'KASCO',
    this.style = 'KSRWL-002JA',
    this.styleCode = 1,
    this.size = 'M',
    this.color = 'BLUE',
    this.plan = 1,
    this.actual = 1,
    this.sumDefect = 1,
  });

  Map<String, dynamic> toMap() {
    return {
      'line': line,
      'Customer': Customer,
      'style': style,
      'styleCode': styleCode,
      'size': size,
      'color': color,
      'plan': plan,
      'actual': actual,
      'sumDefect': sumDefect,
    };
  }

  factory WorkingSummary.fromMap(Map<String, dynamic> map) {
    return WorkingSummary(
      line: map['line']?.toInt(),
      Customer: map['Customer'],
      style: map['style'],
      styleCode: map['styleCode']?.toInt(),
      size: map['size'],
      color: map['color'],
      plan: map['plan']?.toInt(),
      actual: map['actual']?.toInt(),
      sumDefect: map['sumDefect']?.toInt(),
    );
  }

  String toJson() => json.encode(toMap());

  factory WorkingSummary.fromJson(String source) =>
      WorkingSummary.fromMap(json.decode(source));
}
